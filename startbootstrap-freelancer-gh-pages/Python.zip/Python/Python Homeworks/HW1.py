
"""HW1.py --- This homework does a greedy algorithm on a user inputted p and q.
The program displays the sequence of proper fraction whose sums equal p/q """

__author__ = "Lando Slack"
__credits__ = ["Heiko Stowasser, Che Gerro Guava"]
__email__ = "slacklj@mail.uc.edu"


def p_i():
    p = input("What is your first integer?")
    print('p = ')
    print(p)
    return p


def q_i():
    q = input("What is your second integer?")
    print('q = ')
    print(q)
    return q


num = p_i()
dem = q_i()

while dem <= num:
    print('Your first must be less then your second!')
    num = p_i()
    dem = q_i()


s = ''


def greedy(nu, de):
    global s

    if int(de % nu) == 0:
        s += ("1/" + str(int(de/nu)))
        return

    if int(nu % de) == 0:
        s += (int(nu/de))
        return

    if nu > de:
        s += (int(nu/de), " + ")
        greedy(nu%de, de)
        return

    n = int(de/nu) + 1

    s += ("1/"+str(n)+" + ")

    greedy(int(nu*n-de), int(de*n))


greedy(p, q)
print(s, "=", str(num)+"/"+str(dr))
